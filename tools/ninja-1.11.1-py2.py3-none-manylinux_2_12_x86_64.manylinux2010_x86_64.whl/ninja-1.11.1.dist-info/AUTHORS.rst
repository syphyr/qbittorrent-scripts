=======
Credits
=======

Please see the GitHub project page at https://github.com/scikit-build/ninja-python-distributions/graphs/contributors
